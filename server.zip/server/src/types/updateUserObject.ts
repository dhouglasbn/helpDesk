export type UpdateUserObject = {
	newName: string
	newEmail: string
	newPassword: string
}

export type ServiceData = {
  id: string,
  title: string,
  price: string
}